// FITUR 10: SISTEM KEAMANAN & PASSWORD
function login() {
    const u = document.getElementById('user').value;
    const p = document.getElementById('pass').value;
    
    if (u === "XENOS_Exz" && p === "Xenos200411") {
        document.getElementById('login-screen').style.display = 'none';
        document.getElementById('main-app').classList.remove('hidden');
        alert("Welcome, Executioner of Sky!");
    } else {
        alert("USERNAME ATAU PASSWORD SALAH!");
    }
}

// FITUR 7 & 8: TRAP LINK & INFO DEVICE
function genLink() {
    const name = document.getElementById('input-name').value;
    const link = document.getElementById('fake-link').value;
    const term = document.getElementById('terminal');

    if(!name || !link) return alert("Mohon lengkapi data target!");

    document.getElementById('target-name').innerText = name;
    
    // Auto-fill info untuk demo (Realnya didapat saat target klik link)
    document.getElementById('dev-model').innerText = "Android 14 (Detected)";
    document.getElementById('dev-bat').innerText = "78%";

    term.innerHTML = `<span class="cyan">[SUCCESS] Trap Link Generated for: ${name}</span><br>` + term.innerHTML;
    alert("Link Samaran Siap Dikirim!");
}

// FITUR 1, 2, 3, 4, 9: INTERAKSI KONTROL
function cmd(action) {
    const term = document.getElementById('terminal');
    const time = new Date().toLocaleTimeString();
    
    term.innerHTML = `[${time}] EXECUTING: ${action}...<br>` + term.innerHTML;
    
    if(action === 'CAPTURE_CAM') {
        alert("Akses Kamera Terbuka. Foto berhasil diambil.");
    }
}

// FITUR 5: CRASH SYSTEM DURASI
function crash() {
    const hrs = document.getElementById('crash-timer').value;
    const term = document.getElementById('terminal');
    
    if(!hrs) return alert("Masukkan durasi jam!");

    term.innerHTML = `<span style="color:red">[ALERT] TARGET DEVICE FREEZED FOR ${hrs} HOUR(S)</span><br>` + term.innerHTML;
    alert(`Perintah Crash ${hrs} Jam telah dikirim oleh King Galih!`);
}